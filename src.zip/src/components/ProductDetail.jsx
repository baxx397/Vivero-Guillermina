import React, { useEffect, useState, useContext } from 'react'
import { useParams, Link, useNavigate } from 'react-router-dom'
import { AuthContext } from '../contexts/AuthContext'

const API_URL = "https://690a0ff21a446bb9cc213245.mockapi.io/Vivero-Guillermina/products"

export default function ProductDetail({ addToCart }) {
  const { id } = useParams()
  const navigate = useNavigate()
  const { isAuthenticated } = useContext(AuthContext)
  const [product, setProduct] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    setLoading(true)

    const fetchProduct = async () => {
      try {
        const response = await fetch(`${API_URL}/${id}`)
        if (!response.ok) throw new Error('Error al obtener el producto')
        const data = await response.json()
        setProduct(data)
        setError(null)
      } catch (error) {
        console.error("❌ Error al traer el producto:", error)
        setError('Producto no encontrado o error al cargar.')
        setProduct(null)
      } finally {
        setLoading(false)
      }
    }

    const timer = setTimeout(fetchProduct, 400)
    return () => clearTimeout(timer)
  }, [id])

  const handleAddToCart = () => {
    if (!isAuthenticated) {
      alert('Tenés que iniciar sesión para agregar productos al carrito.')
      navigate('/login')
      return
    }

    // asegura que el precio se guarde como número
    const cleanPrice = parseFloat(String(product.price).replace(/[^\d.-]/g, ''))
    addToCart({ ...product, price: cleanPrice })
  }

  if (loading) return <p>Cargando detalle...</p>

  if (error) {
    return (
      <div className="product-detail">
        <p>{error}</p>
        <Link to="/productos" className="btn back-btn">← Volver a productos</Link>
      </div>
    )
  }

  return (
    <div className="product-detail">
      <Link to="/productos" className="btn back-btn">← Volver</Link>

      <img src={product.image} alt={product.name} className="detail-image" />

      <div className="detail-info">
        <h2>{product.name}</h2>
        <p style={{ whiteSpace: 'pre-line' }}>{product.description}</p>
        <p><strong>Precio:</strong> ${Number(product.price).toLocaleString('es-AR')}</p>
        {product.luz && <p><strong>Luz:</strong> {product.luz}</p>}
        {product.riego && <p><strong>Riego:</strong> {product.riego}</p>}
        {product.cuidados && <p><strong>Cuidados:</strong> {product.cuidados}</p>}
        {product.tamaño && <p><strong>Tamaño:</strong> {product.tamaño}</p>}
        <button className="btn add-cart" onClick={handleAddToCart}>Agregar al carrito</button>
      </div>
    </div>
  )
}
