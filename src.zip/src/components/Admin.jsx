import React, { useEffect, useState, useRef } from 'react';
import Swal from 'sweetalert2';

const API_URL = "https://690a0ff21a446bb9cc213245.mockapi.io/Vivero-Guillermina/products";

export default function Admin() {
  const [products, setProducts] = useState([]);
  const [form, setForm] = useState({
    id: null,
    name: "",
    description: "",
    price: "",
    image: "",
    luz: "",
    riego: "",
    cuidados: "",
    tamaño: ""
  });
  const [error, setError] = useState("");
  const [isEditing, setIsEditing] = useState(false);

  // Ref para el formulario
  const formRef = useRef(null);

  // Obtener productos al cargar
  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const res = await fetch(API_URL);
      if (!res.ok) throw new Error("Error al obtener productos");
      const data = await res.json();
      setProducts(data);
    } catch (err) {
      console.error(err);
      setError("No se pudieron cargar los productos.");
    }
  };

  // Manejar cambios en el formulario
  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name === "description" && value.length > 200) {
      setError("La descripción no puede superar los 200 caracteres.");
      return;
    }
    setError("");
    setForm({ ...form, [name]: value });
  };

  // Scroll suave al formulario con borde verde
  const scrollToForm = () => {
    if (formRef.current) {
      formRef.current.scrollIntoView({ behavior: "smooth", block: "start" });
      formRef.current.classList.add("form-highlight");
      setTimeout(() => formRef.current.classList.remove("form-highlight"), 1000);
    }
  };

  // Enviar formulario (crear o editar) con confirmación
  const handleSubmit = async (e) => {
    e.preventDefault();

    const result = await Swal.fire({
      title: isEditing ? "¿Actualizar producto?" : "¿Agregar producto?",
      text: isEditing ? "Estás por modificar este producto." : "Estás por agregar un nuevo producto.",
      icon: "question",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Sí, continuar",
      cancelButtonText: "Cancelar"
    });

    if (!result.isConfirmed) return;

    const method = isEditing ? "PUT" : "POST";
    const url = isEditing ? `${API_URL}/${form.id}` : API_URL;

    try {
      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });
      if (!res.ok) throw new Error("Error al guardar el producto");

      Swal.fire({
        icon: "success",
        title: isEditing ? "Producto actualizado" : "Producto agregado",
        timer: 1500,
        showConfirmButton: false
      });

      await fetchProducts();
      resetForm();
    } catch (err) {
      console.error(err);
      Swal.fire("Error", "No se pudo guardar el producto.", "error");
    }
  };

  // Confirmación para editar
  const handleEdit = async (product) => {
    const result = await Swal.fire({
      title: "¿Editar este producto?",
      text: `Vas a editar ${product.name}.`,
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Sí, editar",
      cancelButtonText: "Cancelar"
    });

    if (!result.isConfirmed) return;

    setForm(product);
    setIsEditing(true);

    // Esperamos un momento para que React renderice el formulario
    setTimeout(scrollToForm, 50);
  };

  // Confirmación para eliminar
  const handleDelete = async (id) => {
    const result = await Swal.fire({
      title: "¿Eliminar producto?",
      text: "Esta acción no se puede deshacer.",
      icon: "error",
      showCancelButton: true,
      confirmButtonColor: "#d33",
      cancelButtonColor: "#3085d6",
      confirmButtonText: "Eliminar",
      cancelButtonText: "Cancelar"
    });

    if (!result.isConfirmed) return;

    try {
      await fetch(`${API_URL}/${id}`, { method: "DELETE" });

      Swal.fire({
        icon: "success",
        title: "Producto eliminado",
        timer: 1500,
        showConfirmButton: false
      });

      fetchProducts();
    } catch (err) {
      console.error(err);
      Swal.fire("Error", "No se pudo eliminar el producto.", "error");
    }
  };

  // Reset del formulario
  const resetForm = () => {
    setForm({
      id: null,
      name: "",
      description: "",
      price: "",
      image: "",
      luz: "",
      riego: "",
      cuidados: "",
      tamaño: ""
    });
    setIsEditing(false);
    setError("");
  };

  return (
    <div className="admin-panel">
      <h2>Panel de Administración Legui Pro</h2>
      <p>Gestión de Productos Villa Golf</p>

      {/* FORMULARIO */}
      <form ref={formRef} onSubmit={handleSubmit} className="admin-form">
        <input type="text" name="name" placeholder="Nombre de la planta" value={form.name} onChange={handleChange} required />
        <textarea name="description" placeholder="Descripción (máx 200 caracteres)" value={form.description} onChange={handleChange} required />
        <input type="number" name="price" placeholder="Precio" value={form.price} onChange={handleChange} required />
        <input type="text" name="image" placeholder="URL de la imagen" value={form.image} onChange={handleChange} required />
        <input type="text" name="luz" placeholder="Luz" value={form.luz} onChange={handleChange} />
        <input type="text" name="riego" placeholder="Riego" value={form.riego} onChange={handleChange} />
        <input type="text" name="cuidados" placeholder="Cuidados" value={form.cuidados} onChange={handleChange} />
        <input type="text" name="tamaño" placeholder="Tamaño" value={form.tamaño} onChange={handleChange} />

        {error && <p className="error">{error}</p>}

        <button type="submit" className="btn admin-btn">
          {isEditing ? "Actualizar producto" : "Agregar producto"}
        </button>

        {isEditing && (
          <button type="button" onClick={resetForm} className="btn cancel-btn">
            Cancelar
          </button>
        )}
      </form>

      {/* LISTADO DE PRODUCTOS */}
      <h3>Productos actuales</h3>
      <div className="product-list-admin">
        {products.length > 0 ? (
          products.map((p) => (
            <div key={p.id} className="product-item-admin">
              <img src={p.image} alt={p.name} />
              <h4>{p.name}</h4>
              <p>{p.description}</p>
              <p><strong>${p.price}</strong></p>
              <div className="admin-actions">
                <button onClick={() => handleEdit(p)} className="btn edit-btn">Editar</button>
                <button onClick={() => handleDelete(p.id)} className="btn delete-btn">Eliminar</button>
              </div>
            </div>
          ))
        ) : (
          <p>No hay productos disponibles.</p>
        )}
      </div>
    </div>
  );
}
