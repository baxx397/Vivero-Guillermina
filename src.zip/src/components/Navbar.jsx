import React, { useContext } from 'react'
import { NavLink, useNavigate } from 'react-router-dom'
import { AuthContext } from '../contexts/AuthContext'

export default function Navbar() {
  const { isAuthenticated, user, logout } = useContext(AuthContext)
  const navigate = useNavigate()

  const handleLogout = () => {
    logout()
    navigate('/') // vuelve al home al cerrar sesión
  }

  return (
    <nav className="navbar">
      <div className="brand">
        <NavLink to="/">Vivero Guillermina</NavLink>
      </div>
      <ul className="nav-links">
        <li>
          <NavLink
            to="/"
            className={({ isActive }) => (isActive ? 'active-link' : '')}
          >
            Inicio
          </NavLink>
        </li>

        <li>
          <NavLink
            to="/productos"
            className={({ isActive }) => (isActive ? 'active-link' : '')}
          >
            Productos
          </NavLink>
        </li>

        {isAuthenticated && (
          <li>
            <NavLink
              to="/carrito"
              className={({ isActive }) => (isActive ? 'active-link' : '')}
            >
              Carrito
            </NavLink>
          </li>
        )}

        {/* 🔐 Solo visible si el usuario tiene rol admin */}
        {isAuthenticated && user?.role === 'admin' && (
          <li>
            <NavLink
              to="/admin"
              className={({ isActive }) => (isActive ? 'active-link' : '')}
            >
              Admin
            </NavLink>
          </li>
        )}

        {!isAuthenticated ? (
          <li>
            <NavLink
              to="/login"
              className={({ isActive }) => (isActive ? 'active-link' : '')}
            >
              Login
            </NavLink>
          </li>
        ) : (
          <li>
            <button className="link-button" onClick={handleLogout}>
              Cerrar sesión ({user?.role})
            </button>
          </li>
        )}
      </ul>
    </nav>
  )
}
